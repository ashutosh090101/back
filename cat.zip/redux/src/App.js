import logo from './logo.svg';
import './App.css';
import MyComponent from './MyComponent';
import GoogleLoginPage from './GoogleLoginPage'

function App() {
  return (
    <>
     <GoogleLoginPage/>
    </>
  );
}

export default App;
