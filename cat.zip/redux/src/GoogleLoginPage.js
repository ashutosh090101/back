import React from 'react';
import { GoogleLogin } from 'react-google-login';

const GoogleLoginButton = () => {
  // Your Google client ID (you can get this from the Google Developer Console)
  const clientId = '1073914463225-c0ubpnd3ut2996fni08v850clgt0md7m.apps.googleusercontent.com';

  const onSuccess = (response) => {
    console.log('Login Success:', response);
    // You can send the response.tokenId to your backend server for validation
    // or use it to get user information
  };

  const onFailure = (error) => {
    console.log('Login Failed:', error);
  };

  return (
    <div>
      <h2>Login with Google</h2>
      <GoogleLogin
        clientId={clientId}
        buttonText="Login with Google"
        onSuccess={onSuccess}
        onFailure={onFailure}
        cookiePolicy="single_host_origin"
        isSignedIn={true}  // Optional: Automatically sign in if the user is already logged in
      />
    </div>
  );
};

export default GoogleLoginButton;
