// MyComponent.js
import React, { useEffect, useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { fetchTodos, fetchUsers, insertUser } from './actions';

function MyComponent() {
  const [userData, setUserData] = useState({ name: '', job: '' });

  const todos = useSelector((state) => state.todos.data);
  const users = useSelector((state) => state.users.data);
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(fetchTodos());
    dispatch(fetchUsers());
  }, [dispatch]);

  const handleInsertUser = (e) => {
    e.preventDefault();
    dispatch(insertUser(userData));
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setUserData((prevUserData) => ({
      ...prevUserData,
      [name]: value,
    }));
  };

  return (
    <div>
      <h2>Todos:</h2>
      <ul>
        {todos ? (
          todos.map((todo) => (
            <li key={todo.id}>{todo.first_name}</li>
          ))
        ) : (
          <li>Loading todos...</li>
        )}
      </ul>
      <h2>Services Data Showing With The Concept of Redux & Redux Toolkit:</h2>
      <ul>
        {users ? (
          users.map((user) => (
            <React.Fragment key={user.id}>
              <li>Service Name: - {user.service_name}</li>
              <li>Description: - {user.description}</li>
              <li>Price: - {user.price}</li>
              <br />
            </React.Fragment>
          ))
        ) : (
          <li>Loading services...</li>
        )}
      </ul>
      <form onSubmit={handleInsertUser}>
        <input
          type="text"
          name="name"
          placeholder="Enter name"
          value={userData.name}
          onChange={handleChange}
        />
        <input
          type="text"
          name="job"
          placeholder="Enter job"
          value={userData.job}
          onChange={handleChange}
        />
        <button type="submit">Add User</button>
      </form>
    </div>
  );
}

export default MyComponent;
