// actions.js
import axios from 'axios';
import { setTodos } from './todosReducer';
import { setUsers } from './usersReducer';

//const API_BASE_URL = 'https://reqres.in/api';
const API_BASE_URL = 'http://localhost:8080/api/v1/service/user-managment-service'
export const fetchTodos = () => {
  return async (dispatch) => {
    try {
      const response = await axios.get(`${API_BASE_URL}/auth/admin/users`);
      dispatch(setTodos(response.data));
    } catch (error) {
      console.error('Error fetching todos:', error);
    }
  };
};

export const fetchUsers = () => {
  return async (dispatch) => {
    try {
      const response = await axios.get(`${API_BASE_URL}/auth/send-mobile-otp`);
      dispatch(setUsers(response.data));
    } catch (error) {
      console.error('Error fetching users:', error);
    }
  };
};

export const insertUser = (userData) => {
  return async (dispatch) => {
    try {
      const response = await axios.post(`${API_BASE_URL}/users`, userData);
      console.log('User inserted successfully:', response.data);
      // After successful insertion, you might want to fetch updated user data
      dispatch(fetchUsers());
    } catch (error) {
      console.error('Error inserting user:', error);
    }
  };
};
