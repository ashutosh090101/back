const { Pool } = require('pg');
require('dotenv').config();

const pool = new Pool({
    connectionString: process.env.DATABASE_URL,
});

exports.savePaymentStatus = async (customerId, sessionId, status) => {
    const query = `
        INSERT INTO payments (customer_id, session_id, status)
        VALUES ($1, $2, $3)
        ON CONFLICT (session_id)
        DO UPDATE SET status = $3;
    `;

    await pool.query(query, [customerId, sessionId, status]);
};
