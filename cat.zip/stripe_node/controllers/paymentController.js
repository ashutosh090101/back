const Stripe = require('stripe');
const { savePaymentStatus } = require('../models/db');
require('dotenv').config();

const stripe = Stripe(process.env.STRIPE_SECRET_KEY);

// Create a checkout session
exports.createCheckoutSession = async (req, res) => {
    const { items, customerId } = req.body;

    try {
        const session = await stripe.checkout.sessions.create({
            payment_method_types: ['card'],
            line_items: items.map(item => ({
                price_data: {
                    currency: 'usd',
                    product_data: {
                        name: item.name,
                    },
                    unit_amount: item.price * 100,
                },
                quantity: item.quantity,
            })),
            mode: 'payment',
            success_url: `${process.env.CLIENT_URL}/success?session_id={CHECKOUT_SESSION_ID}`,
            cancel_url: `${process.env.CLIENT_URL}/cancel`,
            metadata: { customerId },
        });

        res.status(200).json({ sessionId: session.id });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// Handle Stripe webhook for payment status
exports.handleWebhook = async (req, res) => {
    const sig = req.headers['stripe-signature'];
    const endpointSecret = process.env.STRIPE_WEBHOOK_SECRET;

    try {
        // Confirm the raw body is being passed correctly
        //console.log("Raw Body:", req.body.toString());

        // Construct the event using Stripe SDK
        const event = stripe.webhooks.constructEvent(req.body, sig, endpointSecret);

        //console.log("Event Type:", event.type); // Log event type

        if (event.type === 'checkout.session.completed') {
            const session = event.data.object;

            console.log("Session Metadata:", session.metadata);

            // Update payment status in the database
            await savePaymentStatus(session.metadata.customerId, session.id, 'success');
        }

        res.status(200).send('Received');
    } catch (error) {
        console.error("Webhook Error:", error.message);
        res.status(400).send(`Webhook error: ${error.message}`);
    }
};

