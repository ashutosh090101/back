const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const paymentRoutes = require('./routes/payment');

const app = express();

app.use(cors());
//app.use(bodyParser.json());

app.use((req, res, next) => {
    console.log(req.originalUrl)
    if (req.originalUrl === '/api/payment/webhook') {
        console.log("sdfsdfgsdg")
        next(); // Skip JSON parsing for the webhook
    } else {
        express.json()(req, res, next);
    }
});


app.use('/api/payment', paymentRoutes);

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
