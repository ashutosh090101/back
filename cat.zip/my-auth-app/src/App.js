import React, { useEffect } from 'react';
import { useAuth0 } from '@auth0/auth0-react';
import axios from 'axios';

function App() {
  const {
    loginWithRedirect,
    logout,
    user,
    isAuthenticated,
    getAccessTokenSilently,
  } = useAuth0();

  // Function to call the private API endpoint
  // const callApi = async () => {
  //   try {
  //     const token = await getAccessTokenSilently();
  //     console.log('Access Token:', token);  // Add this to check the token
  //     const response = await axios.get('http://localhost:4000/protected', {
  //       headers: {
  //         Authorization: `Bearer ${token}`,
  //       },
  //     });
  //     console.log(response.data,"sdfsdfsdfsdf");
  //   } catch (error) {
  //     console.log(error);
  //   }
  // };

  const callApi = async () => {
    try {
      const token = await getAccessTokenSilently();
      console.log('Access Token:', token); // Check the token for debugging
  
      // Axios POST request with headers passed correctly
      const response = await axios.post(
        'http://localhost:3001/api/v1/auth/social-login', 
        {user}, // Empty data payload for POST request
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
  
      console.log(response.data, "Response data");
    } catch (error) {
      console.error('Error occurred:', error.message || error);
    }
  };
  

  useEffect(() => {
    if (isAuthenticated) {
      console.log('Authenticated User:', user);
    }
  }, [isAuthenticated, user]);

  return (
    <div className="App">
      <header className="App-header">
        {!isAuthenticated ? (
          <>
            <button onClick={() => loginWithRedirect()}>Log In</button>
          </>
        ) : (
          <>
            <h3>Hello, {user?.name}</h3>
            <button
              onClick={() =>
                logout({ returnTo: window.location.origin })
              }
            >
              Log Out
            </button>
            <button onClick={callApi}>Call Private API</button>
          </>
        )}
      </header>
    </div>
  );
}

export default App;
