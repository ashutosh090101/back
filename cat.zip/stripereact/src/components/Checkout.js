import React from 'react';
import { loadStripe } from '@stripe/stripe-js';
import { Elements } from '@stripe/react-stripe-js';
import axios from '../api/payment';

const stripePromise = loadStripe('pk_test_51QU6XTIIfxxuH678Q3IQHiqlteVp8yfjDbnaWQmfeqyaS0LW3g8PWFHQqdp32xfrko2TlEaYLdA8iJHsRwH5fwdu00GGVMtC4H');

const Checkout = () => {
    const handleCheckout = async () => {
        const { data } = await axios.post('/checkout', 
        // {
        //     items: [
        //         { name: 'Product 1', price: 10, quantity: 1 },
        //         { name: 'Product 2', price: 10, quantity: 2 },
        //     ],
        //     customerId: '53001',
        // }
        {
            productName: 'Pro1',
            price: 35, // Total price for all items
            customerId: '676ea8e7da989638b8f8b896', // Replace with actual customer ID
            productDescription: "A detailed course on topic X.",
            //courseId: '63e61a6c8d1f52b9b5ab2c4e', // Optional
            subscriptionPlanId: '678e21fe72130364b158ccb0', // Optional
            productDiscount:20,
            duration:12
        }
        );

        const stripe = await stripePromise;
        await stripe.redirectToCheckout({ sessionId: data.sessionId });
    };

    return (
        <div>
            <h1>Checkout</h1>
            <button onClick={handleCheckout}>Proceed to Checkout</button>
        </div>
    );
};

export default Checkout;
