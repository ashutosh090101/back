import React from 'react';

const Success = () => {
    return <h1>Payment Successful!</h1>;
};

export default Success;
