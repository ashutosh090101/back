import React from 'react';

const Cancel = () => {
    return <h1>Payment Cancelled.</h1>;
};

export default Cancel;
