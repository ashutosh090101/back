const jwt = require('jsonwebtoken');
const authMiddleware = {
   async checkToken(req, res, next){
    let token = req.header('Authorization');

    // Ensure token exists
    if (!token) return res.status(401).json({ message: 'No token, authorization denied' });

    // Remove 'Bearer ' prefix if present
    if (token.startsWith('Bearer ')) {
        token = token.slice(7, token.length);
    }

    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        console.log(decoded, "Decoded Token");
        req.user = decoded.userId;
        next();
    } catch (error) {
        res.status(401).json({ message: 'Invalid token' });
    }
},

async isCorrect(req, res, next) {
    try {
      // Check if user_type includes "admin"
      if (Array.isArray(req.user.user_type) && req.user.user_type.includes("admin")) {
        next();
      } else if (req.user.user_type === "admin") { // If user_type is a string
        next();
      } else {
        throw new ForbiddenError('User is not valid for this route.');
      }
    } catch (e) {
      next(e);
    }
  },


  validateUpdate(req, res, next) {
    try {
        const name = req.body.name;
        const email = req.body.email;
        const password = req.body.password;
      
        if(!name) throw new Error('Name not provided.');
        if(!email) throw new Error('Email not provided.');
        if(!password) throw new Error('Password not provided.');
        
        next();
    } catch(e) {
        next(e);
    }
  },
}

module.exports = authMiddleware;