const User = require('../models/userModel');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

const AuthService = {
    async register(data) {
        const { name, email, password } = data;

        if (!password) {
            throw new Error('Password is required'); // Ensure password is provided
        }

        console.log("Received Password:", password); // Debugging line

        let user = await User.findOne({ email });
        if (user) throw new Error('User already exists');

        const saltRounds = 10; // Ensure saltRounds is a number

        try {
            const hashedPassword = await bcrypt.hash(password, saltRounds);
            console.log("Hashed Password:", hashedPassword); // Debugging line

            user = new User({ name, email, password: hashedPassword });
            await user.save();

            return user;
        } catch (error) {
            console.error("Error hashing password:", error);
            throw new Error("Password hashing failed");
        }
    },

    async login(data) {
        const { email, password } = data;

        const user = await User.findOne({ email });
        if (!user) throw new Error('Invalid credentials');

        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) throw new Error('Invalid credentials');
         
        const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET, { expiresIn: '1h' });

        return { token, user };
    },

    async getAllUsers() {
        return await User.find();
    },

    async getUserById(id) {
        return await User.findById(id);
    },

    async updateUser(id, data) {
        return await User.findByIdAndUpdate(id, data, { new: true });
    },

    async deleteUser(id) {
        return await User.findByIdAndDelete(id);
    }
};

module.exports = AuthService;
