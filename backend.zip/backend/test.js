const bcrypt = require('bcrypt');

async function testBcrypt() {
    const password = "12345";
    const salt = await bcrypt.genSalt(10); // Generates a valid salt

    try {
        console.log("Generated Salt:", salt); // Debugging log

        const hashed = await bcrypt.hash(password, salt);
        console.log("Hashing Success:", hashed);
    } catch (error) {
        console.error("Bcrypt Hashing Error:", error);
    }
}

testBcrypt();
