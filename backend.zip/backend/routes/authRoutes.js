const express = require('express');
const AuthController = require('../controllers/authController');
const authMiddleware = require('../middleware/authMiddleware');

const router = express.Router();

router.post('/register', AuthController.register);
router.post('/login', AuthController.login);
router.get('/users', authMiddleware, AuthController.getAllUsers);
router.get('/users/:id', authMiddleware, AuthController.getUserById);
router.put('/users/:id', authMiddleware, AuthController.updateUser);
router.delete('/users/:id', authMiddleware, AuthController.deleteUser);

module.exports = router;
